<?php
	include("zaglavlje.php");
	$bp=spojiSeNaBazu();
?>
<?php
	$greska="";
	if(isset($_POST['submit'])){
		foreach($_POST as $key => $value)if(strlen($value)==0)$greska="Sva polja za unos su obavezna";
		if(empty($greska)){
			$naslov=$_POST['naslov'];
			$link=$_POST['link'];
			$cijena=$_POST['cijena'];
			$slika=$_POST['slika'];
			$id=$_POST['novi'];
			if($id==0){
				$sql="INSERT INTO video
					(naslov, link, slika, cijena)
					VALUES
					('$naslov','$link','$slika','$cijena');
				";
			}
			else{
				$sql="UPDATE video SET
					link='$link',
					cijena='$cijena',
					slika='$slika',
					naslov='$naslov'
					WHERE id_video='$id'
				";
			}
			izvrsiUpit($bp,$sql);
			header("Location:materijali.php");
		}
	}
	if(isset($_GET['video'])){
		$id=$_GET['video'];
		$sql="SELECT id_video,naslov,link,slika,cijena FROM video WHERE id_video='$id'";
		$rs=izvrsiUpit($bp,$sql);
		list($id,$naslov,$link,$slika,$cijena)=mysqli_fetch_array($rs);
	}
	else{
		$naslov = "";
		$link = "";
		$cijena = "";
		$slika = "";
	}
		if(isset($_POST['reset']))header("Location:video.php");
?>
<form method="POST" action="<?php if(isset($_GET['video']))echo "video.php?video=$id";else echo "video.php";?>">
	<table>
		<caption>
			<?php
				if(isset($_GET['video']))echo "Uredi film";
				else echo "Dodaj film";
			?>
		</caption>
		<tbody>
			<tr>
				<td colspan="2">
					<input type="hidden" name="novi" value="<?php if(!empty($id))echo $id;else echo 0;?>"/>
				</td>
			</tr>
			<tr>
				<td colspan="2" style="text-align:center;">
					<label class="greska"><?php if($greska!="")echo $greska; ?></label>
				</td>
			</tr>
			<tr>
				<td class="lijevi">
					<label for="naslov"><strong>Naslov filma:</strong></label>
				</td>
				<td>
					<input type="text" name="naslov" id="naslov" size="120" maxlength="100"
						placeholder="Naslov filma treba započeti velikim početnim slovom, može uključivati praznine i sadržati do 50 znakova"
						value="<?php if(!isset($_POST['naslov']))echo $naslov; else echo $_POST['naslov'];?>"/>
				</td>
			</tr>
			<tr>
				<td>
					<label for="link"><strong>IMDb:</strong></label>
				</td>
				<td>
					<input type="url" name="link" id="link" size="120" placeholder="Ispravan oblik poveznice je http://www.imdb.com/title/nesto/"
						maxlength="255" value="<?php if(!isset($_POST['link']))echo $link; else echo $_POST['link'];?>"/>
				</td>
			</tr>
			<tr>
				<td>
					<label for="cijena"><strong>Cijena:</strong></label>
				</td>
				<td>
					<input type="number" name="cijena" id="cijena" min="1" max="1000000"
						value="<?php if(!isset($_POST['cijena']))echo $cijena; else echo $_POST['cijena'];?>"/>
				</td>
			</tr>
			<tr>
				<td>
					<label for="slika"><strong>Slika:</strong></label>
				</td>
				<td>
					<?php
						$dir=scandir("materijali");
						echo '<select id="slika" name="slika">';
						foreach($dir as $key => $value){
							if($key<2)continue;
							else if(strcmp((isset($_POST['slika'])?$_POST['slika']:$slika),"materijali/".$value)==0){
								echo '<option value="'."materijali/".$value.'"';
								echo ' selected="selected">'."materijali/".$value;
								echo '</option>';
							}
							else{
								echo '<option value="'."materijali/".$value.'">';
								echo "materijali/".$value;
								echo '</option>';
							}
						}
						echo '</select>';
					?>
				</td>
			</tr>
			<tr>
				<td colspan="2" style="text-align:center;">
					<?php
						if(isset($id)&&$aktivni_korisnik_id==$id||!empty($id))echo '<input type="submit" name="submit" value="Pošalji"/>';
						else echo '<input type="submit" name="reset" value="Izbriši"/><input type="submit" name="submit" value="Pošalji"/>';
					?>
				</td>
			</tr>
		</tbody>
	</table>
</form>
<?php
	zatvoriVezuNaBazu($bp);
	include("podnozje.php");
?>
