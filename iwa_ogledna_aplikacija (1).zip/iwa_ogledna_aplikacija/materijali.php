<?php
	include("zaglavlje.php");
	$bp=spojiSeNaBazu();
?>
<?php
	/*
			najprije je potrebno provjeriti koliko imamo zapisa u tablici korisnici
			kako bi mogli izracunati broj stranica i generirati izbornik
	*/
	$sql="SELECT COUNT(*) FROM video";
	$rs=izvrsiUpit($bp,$sql);
	$red=mysqli_fetch_array($rs);
	$broj_redaka=$red[0];
	$broj_stranica=ceil($broj_redaka/$vel_str_video);

	// dohvacamo podatke za aktivnu stranicu
	$sql="SELECT * FROM video ORDER BY id_video LIMIT ".$vel_str_video;
	if(isset($_GET['stranica'])){
		$sql=$sql." OFFSET ".(($_GET['stranica']-1)*$vel_str_video);
		$aktivna=$_GET['stranica'];
	}
	else $aktivna=1;
	$rs=izvrsiUpit($bp,$sql);

	echo "<table>";
		echo "<caption>Popis raspoloživih filmova</caption>";
		echo "<thead><tr>
		<th>Naslov filma</th>
		<th>Poveznica</th>
		<th>Cijena</th>
		<th>Slika</th>
		<th></th>
	</tr></thead>";
	/*
			while($row=mysqli_fetch_array($rs)){
	 			$ime=$row['ime'];
	 			...
	 		}
	*/
	echo "<tbody>";
	while(list($id,$naslov,$link,$slika,$cijena)=mysqli_fetch_array($rs)){
		echo "<tr>
			<td>$naslov</td>
			<td><a href='$link' class='link'>IMDb</a></td>
			<td>$cijena kn</td>
			<td><figure><img src='$slika' width='70' height='100' alt='Slika iz filma $naslov'/></figure></td>";
			if($aktivni_korisnik_tip==0)echo "<td><a href='video.php?video=$id' class='link'>UREDI</a></td>";
			if($aktivni_korisnik_tip==2)echo "<td><a href='posudba.php?korisnik=$aktivni_korisnik_id&video=$id' class='link'>POSUDI</a></td>";
		echo "</tr>";
	}
	echo "</tbody>";
	echo "</table>";

	// ispis paginacije
	echo '<div id="paginacija">';
	// ako je aktivna stranica prva, nije potrebno stavljati link za prethodnu stranicu
	if ($aktivna!=1){
		$prethodna=$aktivna-1;
		echo "<a class='link' href=\"materijali.php?stranica=".$prethodna."\">&lt;</a>";
	}
	for($i=1;$i<=$broj_stranica;$i++){
		echo "<a class='link";
		if($aktivna==$i)echo " aktivna"; // aktivnu stranicu oznacimo na odgovarajuci nacin
		echo "' href=\"materijali.php?stranica=".$i."\">$i</a>";
	}
	// ako je aktivna stranica zadnja, nije potrebno stavljati link za sljedecu stranicu
	if($aktivna<$broj_stranica){
		$sljedeca=$aktivna+1;
		echo "<a class='link' href=\"materijali.php?stranica=".$sljedeca."\">&gt;</a>";
	}
	echo '<br/>';
	if($aktivni_korisnik_tip==0)echo '<a class="link" href="video.php">DODAJ FILM</a>';
	echo '</div>';
?>
<?php
	zatvoriVezuNaBazu($bp);
	include("podnozje.php");
?>
