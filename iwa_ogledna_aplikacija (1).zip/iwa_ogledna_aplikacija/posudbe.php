<?php
	include("zaglavlje.php");
	$bp=spojiSeNaBazu();
?>
<?php
	if(!isset($_SESSION['aktivni_korisnik']))header("Location:index.php");
	if($aktivni_korisnik_tip==0||$aktivni_korisnik_tip==1){
		echo '<div id="opis">
			<h2>Napomena</h2>
			<p>Datumi se unose u formatu dd.mm.yyyy., npr. 10.10.2016.,
			za pretragu po korisniku unesite jedno ili više slova iz imena ili prezimena</p>
			<br/>
		</div>';
		echo '<form method="GET" action="posudbe.php">
			<table><caption>FILTER</caption><tbody>
			<tr>';
		echo '<td><label for="korisnik">Ime ili prezime:</label>';
		echo '<input type="text" value="';if(isset($_GET['korisnik'])&&!isset($_GET['reset']))echo $_GET['korisnik'];
		echo '" name="korisnik" id="korisnik"/></td>
			<td><label for="video">Naslov filma:</label>';
		echo '<input type="text" value="';if(isset($_GET['video'])&&!isset($_GET['reset']))echo $_GET['video'];
		echo '" name="video" id="video"/></td>';
		echo '<td><label for="od">Od datuma:</label>';
		echo '<input type="text" placeholder="Posudbe" value="';if(isset($_GET['od'])&&!isset($_GET['reset']))echo $_GET['od'];
		echo '" name="od" id="od" size="10" onclick="postaviDatum(this)"/></td>
			<td><label for="do">Do datuma:</label>';
		echo '<input type="text" placeholder="Posudbe" value="';if(isset($_GET['do'])&&!isset($_GET['reset']))echo $_GET['do'];
		echo '" name="do" id="do" size="10" onclick="postaviDatum(this)"/></td>
			<td><input type="submit" name="reset" value="Izbriši"/></td>
			<td><input type="submit" name="submit" value="Filter"/></td>
			</tr></tbody>
			</table></form>
		';
	}
	$sql="SELECT id_posudba,ime AS korisnik,prezime,naslov,datum_posudbe AS od,datum_vracanja AS do
		FROM posudba p,korisnik k,video v
		WHERE
			p.id_korisnik=k.id_korisnik
			AND
			p.id_video=v.id_video
	";

	if($aktivni_korisnik_tip==2)$sql=$sql." AND k.korisnicko_ime='$aktivni_korisnik'";
	if(!isset($_GET['reset'])){
		if(isset($_GET['korisnik'])){
			$korisnik=mysqli_real_escape_string($bp,$_GET['korisnik']);
			$sql=$sql." AND (k.ime like'%$korisnik%' OR k.prezime like'%$korisnik%') ";
		}
		if(isset($_GET['video'])&&!empty($_GET['video'])){
			$naslov=$_GET['video'];
			$sql=$sql." AND v.naslov like'%$naslov%'";
		}
		if(isset($_GET['od'])&&strlen($_GET['od']>0)){
		  $od = strtotime($_GET['od']); // pretvaramo datum iz našeg formata  (10.10.2016.) u php interni format
		  $od=date('Y-m-d H:i:s',$od ); // pretvaramo datum iz php formata u mysqli format
			$sql=$sql." AND datum_posudbe > '$od'";
		}
		if(isset($_GET['do'])&&strlen($_GET['do']>0)){
			$do=strtotime($_GET['do']); // pretvaramo datum iz našeg formata (10.10.2016.) u php interni format
		  $do=date('Y-m-d H:i:s',$do); // pretvaramo datum iz php formata u mysqli format
			$sql=$sql." AND datum_posudbe IS NOT NULL AND datum_posudbe < '$do'";
		}
		if(isset($_GET['sort']))$sql=$sql." ORDER BY ".$_GET['sort'];
		/*
			SELECT id_posudba, korisnicko_ime, naslov, datum_posudbe, datum_vracanja
			FROM posudba p
			INNER JOIN video v ON v.id_video = p.id_video
			INNER JOIN korisnik k ON k.id_korisnik=p.id_korisnik
		*/
	}
	$rs=izvrsiUpit($bp,$sql);
	$par=$putanja.(strpos($putanja,"?")?"&":"?");
	echo "<table>";
	echo "<caption>Stanje posuđenih filmova</caption>";
	echo "<thead><tr>";
	echo "<th><a href='".$par."sort=korisnik' class='sortable'>Korisnik <img src='images/strelica.png' alt='strelica' style='border:0;' title='Sortiraj prema korisniku'/></a></th>";
	echo "<th><a href='".$par."sort=naslov' class='sortable'>Film <img src='images/strelica.png' alt='strelica' style='border:0;' title='Sortiraj prema naslovu'/></a></th>";
	echo "<th><a href='".$par."sort=od' class='sortable'>Datum posudbe <img src='images/strelica.png' alt='strelica' style='border:0;' title='Sortiraj prema datumu posudbe'/></a></th>";
	echo "<th><a href='".$par."sort=do' class='sortable'>Datum vraćanja <img src='images/strelica.png' alt='strelica' style='border:0;' title='Sortiraj prema datumu vraćanja'/></a></th>";
	echo "</tr></thead>";
	date_default_timezone_set("Europe/Zagreb");
	/*
			while($row=mysqli_fetch_array($rs)){
				$ime=$row['ime'];
				...
			}
	*/
	echo "<tbody>";
	while(list($id,$ime,$prezime,$video,$datum_posudbe,$datum_vracanja)=mysqli_fetch_array($rs)){
		$vracanje="";
		$posudba=date("d.m.Y.",strtotime($datum_posudbe));
		if($datum_vracanja!=null)$vracanje=date("d.m.Y.",strtotime($datum_vracanja));
		else if($aktivni_korisnik_tip==0||$aktivni_korisnik_tip==1)$vracanje="<a href='vracanje.php?id=$id' class='link'>VRATI FILM</a>";
		echo "<tr>
			<td>$ime $prezime</td>
			<td>$video</td>
			<td>$posudba</td>
			<td>$vracanje</td>
		</tr>";
	}
	echo "</tbody>";
	echo "</table>";
	if($aktivni_korisnik_tip==0||$aktivni_korisnik_tip==1)echo '<div id="paginacija"><a href="posudba.php" class="link">DODAJ POSUDBU</a></div>';
?>
<?php
	zatvoriVezuNaBazu($bp);
	include("podnozje.php");
?>
