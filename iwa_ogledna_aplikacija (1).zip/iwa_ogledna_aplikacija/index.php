<?php
	include("zaglavlje.php");
?>

<article>
	<div id="opis">
		<h2>Ogledna aplikacija - Demo videoteka</h2>
		<p>Jednostavna aplikacija simulira videoteku, postoji mogućnost dodavanja i uređivanja korisnika, filmova i posudbi</p>
	</div>
	<br/>
	<table>
		<caption>Korisnici sustava</caption>
		<thead>
			<tr>
				<th class="lijevi">Popis uloga</th>
				<th>Opis uloga</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>Administrator</td>
				<td>Dodavanje i uređivanje korisnika i filmova, definiranje uloga novih korisnika</td>
			</tr>
			<tr>
				<td>Zaposlenik</td>
				<td>Dodavanje običnih korisnika i njihovo uređivanje, posuđivanje i vraćanje filmova</td>
			</tr>
			<tr>
				<td>Obični korisnik</td>
				<td>Posuđivanje filmova i pregledavanje vlastitih posudbi</td>
			</tr>
			<tr>
				<td>Anonimni korisnik</td>
				<td>Pregledavanje korisnika i filmova</td>
			</tr>
		</tbody>
	</table>
	<br/>
	<table>
		<caption>Datoteke sustava</caption>
		<thead>
			<tr>
				<th class="lijevi">Popis datoteka</th>
				<th>Opis datoteka</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>baza.php</td>
				<td>Skripta za rad s bazom podataka</td>
			</tr>
			<tr>
				<td>index.php</td>
				<td>Kratak opis aplikacije</td>
			</tr>
			<tr>
				<td>zaglavlje.php</td>
				<td>Zaglavlje, sve ostale datoteke je uključuju, sadrži meni i uključuje css i javascript</td>
			</tr>
			<tr>
				<td>podnozje.php</td>
				<td>Podnožje stranice, ikone validatora</td>
			</tr>
			<tr>
				<td>video.css</td>
				<td>CSS upute</td>
			</tr>
			<tr>
				<td>video.js</td>
				<td>JS naredbe</td>
			</tr>
			<tr>
				<td>korisnici.php</td>
				<td>Tablica koja izlistava korisnike, ako je tip korisnika administrator ili zaposlenik postoji mogućnost dodavanja novog korisnika</td>
			</tr>
			<tr>
				<td>materijali.php</td>
				<td>Tablica koja izlistava sadržaje koji se mogu posuditi, obični korisnik ima mogućnost posudbe</td>
			</tr>
			<tr>
				<td>posudbe.php</td>
				<td>Tablica koja izlistava posudbe svih korisnika ako je tip administrator ili zaposlenik, mogućnost unosa nove posudbe i filtriranja prema korisniku ili datumu; za običnog korisnika izlistava njegove posudbe</td>
			</tr>
			<tr>
				<td>korisnik.php</td>
				<td>Obrazac za unos novog ili uređivanje postojećeg korisnika</td>
			</tr>
			<tr>
				<td>video.php</td>
				<td>Obrazac za dodavanje novog i ispis postojećeg sadržaja</td>
			</tr>
			<tr>
				<td>posudba.php</td>
				<td>Obrazac za unos posudbe, odabir korisnika i sadržaja koji se posuđuje</td>
			</tr>
			<tr>
				<td>vracanje.php</td>
				<td>Obrazac za vraćanje posuđene građe, ispisuje broj dana i cijenu</td>
			</tr>
			<tr>
				<td>login.php</td>
				<td>Obrazac za prijavu u sustav</td>
			</tr>
		</tbody>
	</table>
</article>

<?php
	include("podnozje.php");
?>
