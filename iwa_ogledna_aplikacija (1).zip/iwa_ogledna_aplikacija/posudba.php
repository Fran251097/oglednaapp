<?php
	include("zaglavlje.php");
	$bp=spojiSeNaBazu();
?>
<?php
	if(!isset($_SESSION['aktivni_korisnik_tip'])||$_SESSION['aktivni_korisnik_tip']==2)header("Location:index.php");
	if(isset($_REQUEST['korisnik'])){
		$korisnik=$_REQUEST['korisnik'];
		$video=$_REQUEST['video'];
		$sql="INSERT INTO posudba
			(id_korisnik,id_video,datum_posudbe) VALUES
			($korisnik,$video,now());
		";
		izvrsiUpit($bp,$sql);
		header("Location:posudbe.php");
	}
?>

<form method="POST" action="posudba.php">
	<table>
		<caption>Dodaj posudbu</caption>
		<tbody>
			<tr>
				<td class="lijevi">
					<label for="korisnik"><strong>Ime i prezime korisnika:</strong></label>
				</td>
				<td>
					<select id="korisnik" name="korisnik">
						<?php
							$sql="SELECT id_korisnik,ime,prezime
								FROM korisnik WHERE id_tip > 0";
							$rs=izvrsiUpit($bp,$sql);
							while(list($id,$ime,$prezime)=mysqli_fetch_array($rs))echo "<option value='$id'>$ime $prezime</option>";
						?>
					</select>
				</td>
			</tr>
			<tr>
				<td>
					<label for="video"><strong>Naslov filma:</strong></label>
				</td>
				<td>
					<select id="video" name="video">
						<?php
							$sql="SELECT id_video,naslov
									FROM video";
							$rs=izvrsiUpit($bp,$sql);
							while(list($id,$naslov)=mysqli_fetch_array($rs))echo "<option value='$id'>$naslov</option>";
						?>
					</select>
				</td>
			</tr>
			<tr>
				<td colspan="2" style="text-align:center;">
					<input name="submit" type="submit" value="Pošalji"/>
				</td>
			</tr>
		</tbody>
	</table>
</form>
<?php
	zatvoriVezuNaBazu($bp);
	include("podnozje.php");
?>
