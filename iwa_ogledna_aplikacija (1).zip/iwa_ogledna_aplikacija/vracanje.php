<?php
	include("zaglavlje.php");
	$bp=spojiSeNaBazu();
?>
<?php
	if(!isset($_SESSION['aktivni_korisnik_tip'])||$_SESSION['aktivni_korisnik_tip']==2) header("Location:index.php");
	if(isset($_GET['id'])){
		$obavijest="";
		$id=$_GET['id'];
		$sql="SELECT cijena, datediff(now(), datum_posudbe)
			FROM posudba p
			INNER JOIN video v ON v.id_video = p.id_video
			WHERE id_posudba=$id";

		$rs=izvrsiUpit($bp,$sql);
		list($cijena,$dani)=mysqli_fetch_array($rs);
		$ukupno=$cijena*$dani;
		$obavijest="Film je posuđen na $dani dan/dana i za naplatiti je $cijena kn po danu, što ukupno iznosi $ukupno kn";
	}
	if(isset($_POST['vraceno'])){
		$id=$_POST['posudba_id'];
		$sql="UPDATE posudba SET datum_vracanja=now() WHERE id_posudba=$id";
		izvrsiUpit($bp,$sql);
		header ("Location:posudbe.php");
	}
?>
<form method="POST" action="vracanje.php">
	<table>
		<caption>Vraćanje filma</caption>
		<tbody>
			<tr>
				<td>
					<strong>Opis:</strong>
				</td>
				<td>
					<pre><?php echo $obavijest;?></pre>
				</td>
			</tr>
			<tr>
				<td colspan="2" style="text-align:center;">
					<input type="hidden" name="posudba_id" value="<?php echo $id;?>"/>
					<input type="submit" name="vraceno" value="Vrati"/>
				</td>
			</tr>
		</tbody>
	</table>
</form>
<?php
	zatvoriVezuNaBazu($bp);
	include("podnozje.php");
?>
